﻿export interface RowRecordMap {
    [key: number]: {}
}
