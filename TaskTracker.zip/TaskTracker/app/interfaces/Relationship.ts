﻿export interface Relationship {
    parent: string;
    children: string[];
}
