﻿import { Item } from "./Item"

export interface Items extends Array<Item> { }