﻿import { Store } from "../classes/Store"

export interface KeyStoreMap {
    [key: string]: Store;
}

