﻿import { Store } from "../classes/Store"

export interface ChildRecordInfo {
    store: Store;
    childrenIndices: number[];
}
