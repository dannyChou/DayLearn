﻿export class SequenceModel {
    key: string;
    n: number;

    constructor(key: string) {
        this.key = key;
        this.n = 0;
    }
}