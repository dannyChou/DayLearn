define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class SequenceModel {
        constructor(key) {
            this.key = key;
            this.n = 0;
        }
    }
    exports.SequenceModel = SequenceModel;
});
//# sourceMappingURL=SequenceModel.js.map