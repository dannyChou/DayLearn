define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class TemplateElement {
        constructor(item, guid) {
            this.item = item;
            this.guid = guid;
        }
    }
    exports.TemplateElement = TemplateElement;
});
//# sourceMappingURL=TemplateElement.js.map