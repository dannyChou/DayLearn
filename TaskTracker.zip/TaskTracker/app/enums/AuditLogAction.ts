﻿export enum AuditLogAction {
    Create,
    Update,
    Delete
}
