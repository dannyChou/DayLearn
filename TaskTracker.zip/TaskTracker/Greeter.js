"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Greeter {
    constructor() {
    }
    greet() {
    }
}
exports.Greeter = Greeter;
//# sourceMappingURL=Greeter.js.map